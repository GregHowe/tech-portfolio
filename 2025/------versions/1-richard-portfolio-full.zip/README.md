# Richard's Portfolio (Full Demo)

This repository contains a runnable minimal **Fullstack .NET + Vue** demo intended for interview review.

## What is included
- backend-dotnet-postgres: .NET 8 Web API (EF Core, Repository/Service pattern, JWT stub)
- frontend-vue-demo: Vue 3 + Vite + TypeScript frontend (Axios, simple Product list)
- fullstack-dockerized: Docker Compose to run backend + frontend + Postgres
- docs/: Case study PDF, coding guidelines, architecture diagram

## Quick start (Docker required)
```bash
cd fullstack-dockerized
docker compose up --build
```
- Backend: http://localhost:5000/swagger
- Frontend: http://localhost:8080

## Running tests
### Backend (xUnit)
From `backend-dotnet-postgres` folder:
```bash
dotnet test
```

### Frontend (Jest)
From `frontend-vue-demo` folder:
```bash
npm install
npm run test
```

## Notes
- This is a demo scaffold. You can run migrations and seed data in the backend to populate initial products.
- Do not publish any proprietary customer code. These are sample implementations.
