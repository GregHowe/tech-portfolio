# backend-dotnet-postgres (sample)
.NET 8 Web API with EF Core (PostgreSQL).

## Run locally (with Docker Compose)
From repository root:
```bash
cd fullstack-dockerized
docker compose up --build
```

## Notes
- The connection string is provided via environment variables in docker-compose.yml
- To run migrations locally: install dotnet-ef and run `dotnet ef migrations add Initial` then `dotnet ef database update`
