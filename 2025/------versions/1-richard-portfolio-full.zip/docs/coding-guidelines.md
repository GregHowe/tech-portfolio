# Coding Guidelines

Keep code simple and maintainable.
- C# naming: PascalCase for classes and methods
- Use DI and keep controllers thin
- Use async for I/O
- Frontend: Composition API + TypeScript
- Tests: xUnit for backend, Jest for frontend
