# 💼 Richard's Portfolio (Upgraded)

![.NET](https://img.shields.io/badge/.NET-8.0-blue) ![Vue](https://img.shields.io/badge/Vue-3-green) ![Postgres](https://img.shields.io/badge/Postgres-15-blueviolet) ![Docker](https://img.shields.io/badge/Docker-Compose-2496ED) ![Tests](https://img.shields.io/badge/Tests-xUnit%20%7C%20Jest-success)

This repo contains a runnable demo for interview review.

## Docs
- <a href="docs/case-study-erp.pdf" target="_blank">Case Study: ERP Modernization</a>
- <a href="docs/coding-guidelines.md" target="_blank">Coding Guidelines</a>
- <a href="docs/architecture-diagram.png" target="_blank">Architecture Diagram</a>

## Quick start
```bash
cd fullstack-dockerized
docker compose up --build
```
- Backend: http://localhost:5000/swagger
- Frontend: http://localhost:8080
