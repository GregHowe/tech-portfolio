# Coding Guidelines

Keep code simple and maintainable.

## Backend (.NET)
- Use DI, keep controllers thin
- Use EF Core for data access
- EnsureCreated() in demo, use migrations in production

## Frontend (Vue)
- Composition API + TypeScript
- Centralize API calls

## Tests
- xUnit for backend
- Jest for frontend
