# backend-dotnet-postgres (upgraded)
.NET 8 Web API with EF Core (PostgreSQL) with demo seeding (EnsureCreated) and tests.

## Run locally (with Docker Compose)
From repository root:
```bash
cd fullstack-dockerized
docker compose up --build
```

## Notes
- The app uses `EnsureCreated()` to create schema in demo environments and `DataSeeder` to insert sample products.
- To run tests: `dotnet test` inside backend project.
