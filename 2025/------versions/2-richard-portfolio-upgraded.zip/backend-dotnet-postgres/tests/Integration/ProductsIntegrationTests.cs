using System.Net;
using System.Net.Http.Json;
using Microsoft.AspNetCore.Mvc.Testing;
using ProductApi.Models;
using Xunit;

public class ProductsIntegrationTests : IClassFixture<WebApplicationFactory<Program>>
{
    private readonly WebApplicationFactory<Program> _factory;
    public ProductsIntegrationTests(WebApplicationFactory<Program> factory) => _factory = factory;

    [Fact]
    public async Task GetAll_ReturnsOkAndSeededProducts()
    {
        var client = _factory.CreateClient();
        var res = await client.GetAsync("/api/products");
        Assert.Equal(HttpStatusCode.OK, res.StatusCode);

        var list = await res.Content.ReadFromJsonAsync<Product[]>();
        Assert.NotNull(list);
        Assert.NotEmpty(list);
    }
}
